"use client"

import { useState, useRef, useEffect } from "react"
import { Heart, MessageCircle, Snowflake, Home, Calendar, PlusSquare, Search, Bell, Settings, Flame, ChevronLeft, ChevronRight, ImageIcon, Camera, Plus, Users, Lock, HelpCircle, Info, Cloud, Sun, CloudRain } from "lucide-react"

interface Post {
  id: number
  username: string
  avatar: string
  timeAgo: string
  tag?: {
    icon: "cold" | "hot" | "fun"
    label: string
  }
  image: string
  likes: number
  comments: number
  song?: {
    title: string
    artist: string
  }
}

interface UploadedPost {
  id: number
  image: string
  tag: { icon: "cold"; label: string }
  likes: number
  comments: number
  song: { title: string; artist: string }
  weather?: {
    temperature: number
    condition: string
    location: string
  }
}

interface ClosetItem {
  id: number
  image: string
  season: "spring" | "summer" | "fall" | "winter"
}

const posts: Post[] = [
  {
    id: 1,
    username: "irene_yk",
    avatar: "/placeholder-avatar-1.jpg",
    timeAgo: "3h ago",
    tag: { icon: "cold", label: "cold" },
    image: "https://hebbkx1anhila5yf.public.blob.vercel-storage.com/image-lANP6FOV2V2R2mw2nXKpuNfUMhzV3f.png",
    likes: 18,
    comments: 4,
    song: { title: "DAISIES", artist: "Justin Bieber" }
  },
  {
    id: 2,
    username: "jiankimm",
    avatar: "/placeholder-avatar-2.jpg",
    timeAgo: "4h ago",
    image: "https://hebbkx1anhila5yf.public.blob.vercel-storage.com/image-OfqLCHguo3VnVbrKjMSFnG80KftoXQ.png",
    likes: 42,
    comments: 8,
  },
  {
    id: 3,
    username: "alex_photos",
    avatar: "/placeholder-avatar-3.jpg",
    timeAgo: "6h ago",
    tag: { icon: "fun", label: "vibes" },
    image: "https://hebbkx1anhila5yf.public.blob.vercel-storage.com/image-3PvWjf4sAKwpf3WzM3TwTd1BzNvz8r.png",
    likes: 89,
    comments: 12,
    song: { title: "Blinding Lights", artist: "The Weeknd" }
  }
]

// Calendar outfit data
const outfitDays: Record<number, string> = {
  1: "outfit1",
  2: "outfit2", 
  9: "outfit3"
}

export default function App() {
  const [activeTab, setActiveTab] = useState("feed")
  const [likedPosts, setLikedPosts] = useState<number[]>([])
  const [likedUploaded, setLikedUploaded] = useState<number[]>([])
  const [currentMonth] = useState({ month: "May", year: 2026 })
  const [capturedImage, setCapturedImage] = useState<string | null>(null)
  const [uploadedPosts, setUploadedPosts] = useState<UploadedPost[]>([])
  const [searchQuery, setSearchQuery] = useState("")
  const [showNotifications, setShowNotifications] = useState(false)
  const [showFriendRequests, setShowFriendRequests] = useState(false)
  const [friendRequestsTab, setFriendRequestsTab] = useState<"received" | "sent">("received")
  const [showSettings, setShowSettings] = useState(false)
  const [showComments, setShowComments] = useState(false)
  const [selectedPost, setSelectedPost] = useState<Post | null>(null)
  const [selectedUploadedPost, setSelectedUploadedPost] = useState<UploadedPost | null>(null)
  const [uploadedPostComments, setUploadedPostComments] = useState<Record<number, { id: number; username: string; text: string; timeAgo: string }[]>>({})
  const [commentInput, setCommentInput] = useState("")
  const [currentWeather, setCurrentWeather] = useState<{ temperature: number; condition: string } | null>(null)
  const [showNotificationSettings, setShowNotificationSettings] = useState(false)
  const [showHelp, setShowHelp] = useState(false)
  const [notificationToggles, setNotificationToggles] = useState({
    friendRequests: true,
    comments: true,
    likes: false
  })
  const fileInputRef = useRef<HTMLInputElement>(null)

  // Fetch weather for Davis, California
  useEffect(() => {
    const fetchWeather = async () => {
      try {
        // Davis, California coordinates: 38.5449, -121.7405
        const response = await fetch(
          'https://api.open-meteo.com/v1/forecast?latitude=38.5449&longitude=-121.7405&current=temperature_2m,weather_code&temperature_unit=fahrenheit'
        )
        const data = await response.json()
        const temp = Math.round(data.current.temperature_2m)
        const weatherCode = data.current.weather_code
        
        // Map weather code to condition
        let condition = "Clear"
        if (weatherCode >= 0 && weatherCode <= 3) condition = "Clear"
        else if (weatherCode >= 45 && weatherCode <= 48) condition = "Foggy"
        else if (weatherCode >= 51 && weatherCode <= 67) condition = "Rainy"
        else if (weatherCode >= 71 && weatherCode <= 77) condition = "Snowy"
        else if (weatherCode >= 80 && weatherCode <= 99) condition = "Stormy"
        
        setCurrentWeather({ temperature: temp, condition })
      } catch (error) {
        // Fallback weather
        setCurrentWeather({ temperature: 72, condition: "Clear" })
      }
    }
    fetchWeather()
  }, [])

  // Recommended friends data
  const recommendedFriends = [
    { id: 1, name: "Brian Choi", username: "b.choi" },
    { id: 2, name: "mosesmoon", username: "moonste" },
    { id: 3, name: "alex", username: "alextaetyang" },
    { id: 4, name: "Boey", username: "soy_beanz" },
    { id: 5, name: "Aiden", username: "kim.aidenn" },
    { id: 6, name: "Ashley", username: "ashleyeskim" },
  ]

  // Notifications data
  const notifications = [
    { id: 1, text: <><span className="font-semibold">Erin</span> and <span className="font-semibold">Eileen</span> commented on your post.</> },
    { id: 2, text: <><span className="font-semibold">Jessica</span> loved on your post.</> },
    { id: 3, text: <><span className="font-semibold">Sorina</span> has also commented on their post.</> },
  ]

  // Friend requests data
  const friendRequests = [
    { id: 1, name: "sydney", username: "sydneychoi" },
    { id: 2, name: "Walden", username: "waldenl" },
    { id: 3, name: "Kai", username: "kainakafuji" },
  ]

  // Comments data for posts
  const postComments: Record<number, { id: number; username: string; text: string; timeAgo: string }[]> = {
    1: [
      { id: 1, username: "eeileen", text: "very cute!", timeAgo: "55m ago" },
      { id: 2, username: "jessica", text: "love this look!", timeAgo: "1h ago" },
      { id: 3, username: "brian", text: "so stylish", timeAgo: "2h ago" },
      { id: 4, username: "alex", text: "amazing!", timeAgo: "3h ago" },
    ],
    2: [
      { id: 1, username: "mosesmoon", text: "nice fit!", timeAgo: "30m ago" },
      { id: 2, username: "sydney", text: "where did you get this?", timeAgo: "1h ago" },
    ],
    3: [
      { id: 1, username: "walden", text: "fire!", timeAgo: "20m ago" },
      { id: 2, username: "kai", text: "love the vibes", timeAgo: "45m ago" },
    ],
  }

  const openComments = (post: Post) => {
    setSelectedPost(post)
    setSelectedUploadedPost(null)
    setShowComments(true)
  }

  const openUploadedComments = (post: UploadedPost) => {
    setSelectedUploadedPost(post)
    setSelectedPost(null)
    setShowComments(true)
  }

  const handleAddComment = () => {
    if (!commentInput.trim()) return
    
    if (selectedUploadedPost) {
      const newComment = {
        id: Date.now(),
        username: "suue.04",
        text: commentInput.trim(),
        timeAgo: "Just now"
      }
      setUploadedPostComments(prev => ({
        ...prev,
        [selectedUploadedPost.id]: [...(prev[selectedUploadedPost.id] || []), newComment]
      }))
      // Update comment count on the uploaded post
      setUploadedPosts(prev => prev.map(p => 
        p.id === selectedUploadedPost.id 
          ? { ...p, comments: p.comments + 1 }
          : p
      ))
    }
    setCommentInput("")
  }

  const toggleLike = (postId: number) => {
    setLikedPosts(prev => 
      prev.includes(postId) 
        ? prev.filter(id => id !== postId)
        : [...prev, postId]
    )
  }

  const toggleLikeUploaded = (postId: number) => {
    setLikedUploaded(prev => 
      prev.includes(postId) 
        ? prev.filter(id => id !== postId)
        : [...prev, postId]
    )
  }

  const handleCameraClick = () => {
    fileInputRef.current?.click()
  }

  const handleFileChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0]
    if (file) {
      const reader = new FileReader()
      reader.onloadend = () => {
        setCapturedImage(reader.result as string)
      }
      reader.readAsDataURL(file)
    }
  }

  const handleSend = () => {
    if (capturedImage) {
      const newPost: UploadedPost = {
        id: Date.now(),
        image: capturedImage,
        tag: { icon: "cold", label: "cold" },
        likes: 0,
        comments: 0,
        song: { title: "DAISIES", artist: "Justin Bieber" },
        weather: currentWeather ? {
          temperature: currentWeather.temperature,
          condition: currentWeather.condition,
          location: "Davis, CA"
        } : undefined
      }
      setUploadedPosts(prev => [newPost, ...prev])
      setCapturedImage(null)
      setActiveTab("feed")
    }
  }

  const getTagIcon = (icon: string) => {
    switch (icon) {
      case "cold":
        return <Snowflake className="w-4 h-4" />
      default:
        return <Snowflake className="w-4 h-4" />
    }
  }

  const getWeatherIcon = (condition: string) => {
    switch (condition.toLowerCase()) {
      case "rainy":
      case "stormy":
        return <CloudRain className="w-3.5 h-3.5" />
      case "cloudy":
      case "foggy":
        return <Cloud className="w-3.5 h-3.5" />
      default:
        return <Sun className="w-3.5 h-3.5" />
    }
  }

  const getTemperatureLabel = (temp: number): string => {
    if (temp < 32) return "Freezing"
    if (temp < 55) return "Cold"
    if (temp < 75) return "Cool"
    return "Hot"
  }

  // Generate calendar days for May 2026
  const daysInMonth = 31
  const startDay = 5 // May 2026 starts on Friday (index 5)
  const calendarDays = []
  
  for (let i = 0; i < startDay; i++) {
    calendarDays.push(null)
  }
  for (let i = 1; i <= daysInMonth; i++) {
    calendarDays.push(i)
  }

  // Handler for navigating to notifications from settings
  const handleNotificationsFromSettings = () => {
    setShowSettings(false)
    setShowNotificationSettings(true)
  }

  const toggleNotificationSetting = (key: keyof typeof notificationToggles) => {
    setNotificationToggles(prev => ({
      ...prev,
      [key]: !prev[key]
    }))
  }

  const renderFeed = () => (
    <div className="flex-1 overflow-y-auto pb-20">
      {/* User's Uploaded Posts */}
      {uploadedPosts.map((post) => (
        <div key={`user-${post.id}`} className="px-4 py-3">
          {/* User Info */}
          <div className="flex items-center gap-3 mb-3">
            <div className="w-10 h-10 rounded-full bg-muted overflow-hidden">
              <img src="https://hebbkx1anhila5yf.public.blob.vercel-storage.com/image-se3x2GwtYowXEv9BuXujrP5F9U6bMq.png" alt="Profile" className="w-full h-full object-cover" />
            </div>
            <div>
              <p className="font-medium text-foreground text-sm">httpssu</p>
              <p className="text-xs text-muted-foreground">Just now</p>
            </div>
          </div>

          {/* Post Card */}
          <div className="relative bg-card rounded-2xl overflow-hidden shadow-sm border border-border">
            {/* Weather & Cold Badge */}
            <div className="absolute top-3 left-3 flex items-center gap-2 z-10">
              {post.weather ? (
                <div className="flex items-center gap-1.5 bg-blue-500/90 backdrop-blur-sm text-white px-3 py-1.5 rounded-full">
                  {post.weather.temperature >= 75 ? (
                    <Flame className="w-4 h-4" />
                  ) : (
                    <Snowflake className="w-4 h-4" />
                  )}
                  <span className="text-sm font-medium">{getTemperatureLabel(post.weather.temperature)}</span>
                  <span className="text-sm font-medium">{post.weather.temperature}°F</span>
                </div>
              ) : (
                <div className="flex items-center gap-1.5 text-cyan-500">
                  <Snowflake className="w-4 h-4" />
                  <span className="text-sm font-medium">{post.tag.label}</span>
                </div>
              )}
            </div>

            {/* Image */}
            <div className="aspect-square bg-gradient-to-br from-muted/50 to-muted flex items-center justify-center overflow-hidden">
              <img src={post.image} alt="Outfit" className="w-full h-full object-contain" />
            </div>

            {/* Bottom Info */}
            <div className="absolute bottom-0 left-0 right-0 p-3 flex items-center">
              <div className="flex items-center gap-3 text-muted-foreground">
                <button 
                  onClick={() => toggleLikeUploaded(post.id)}
                  className="flex items-center gap-1 transition-colors"
                >
                  <Heart 
                    className={`w-5 h-5 ${likedUploaded.includes(post.id) ? 'fill-red-500 text-red-500' : ''}`} 
                  />
                  <span className="text-sm">
                    {post.likes + (likedUploaded.includes(post.id) ? 1 : 0)}
                  </span>
                </button>
                <button 
                  onClick={() => openUploadedComments(post)}
                  className="flex items-center gap-1"
                >
                  <MessageCircle className="w-5 h-5" />
                  <span className="text-sm">{post.comments}</span>
                </button>
              </div>
            </div>
          </div>
        </div>
      ))}

      {/* Other Users' Posts */}
      {posts.map((post) => (
        <div key={post.id} className="px-4 py-3">
          {/* User Info */}
          <div className="flex items-center gap-3 mb-3">
            <div className="w-10 h-10 rounded-full bg-muted overflow-hidden">
              <div className="w-full h-full bg-gradient-to-br from-muted to-muted-foreground/20"></div>
            </div>
            <div>
              <p className="font-medium text-foreground text-sm">{post.username}</p>
              <p className="text-xs text-muted-foreground">{post.timeAgo}</p>
            </div>
          </div>

          {/* Post Card */}
          <div className="relative bg-card rounded-2xl overflow-hidden shadow-sm border border-border">
            {/* Tag */}
            {post.tag && (
              <div className="absolute top-3 left-3 flex items-center gap-1.5 text-cyan-500 z-10">
                {getTagIcon(post.tag.icon)}
                <span className="text-sm font-medium">{post.tag.label}</span>
              </div>
            )}

            {/* Image */}
            <div className="aspect-square bg-gradient-to-br from-muted/50 to-muted flex items-center justify-center overflow-hidden">
              <img src={post.image} alt="Outfit" className="w-full h-full object-contain" />
            </div>

            {/* Bottom Info */}
            <div className="absolute bottom-0 left-0 right-0 p-3 flex items-center">
              <div className="flex items-center gap-3 text-muted-foreground">
                <button 
                  onClick={() => toggleLike(post.id)}
                  className="flex items-center gap-1 transition-colors"
                >
                  <Heart 
                    className={`w-5 h-5 ${likedPosts.includes(post.id) ? 'fill-red-500 text-red-500' : ''}`} 
                  />
                  <span className="text-sm">
                    {post.likes + (likedPosts.includes(post.id) ? 1 : 0)}
                  </span>
                </button>
                <button 
                  onClick={() => openComments(post)}
                  className="flex items-center gap-1"
                >
                  <MessageCircle className="w-5 h-5" />
                  <span className="text-sm">{post.comments}</span>
                </button>
              </div>
            </div>
          </div>
        </div>
      ))}
    </div>
  )

  const renderProfile = () => (
    <div className="flex-1 overflow-y-auto pb-20">
      {/* Profile Header */}
      <div className="px-4 py-2 flex items-center justify-between">
        <span className="text-sm font-medium text-muted-foreground">@httpssu</span>
        <div className="flex items-center gap-3">
          <button className="relative" onClick={() => setShowNotifications(true)}>
            <Bell className="w-5 h-5 text-foreground" />
            <span className="absolute -top-1 -right-1 w-4 h-4 bg-red-500 text-white text-[10px] rounded-full flex items-center justify-center">3</span>
          </button>
          <button onClick={() => setShowSettings(true)}>
            <Settings className="w-5 h-5 text-muted-foreground" />
          </button>
        </div>
      </div>

      {/* Profile Info */}
      <div className="px-4 py-4 flex items-center gap-4">
        <div className="relative">
          <div className="w-16 h-16 rounded-full bg-muted overflow-hidden">
            <img src="https://hebbkx1anhila5yf.public.blob.vercel-storage.com/image-se3x2GwtYowXEv9BuXujrP5F9U6bMq.png" alt="Profile" className="w-full h-full object-cover" />
          </div>
          {uploadedPosts.length > 0 && (
            <div className="absolute -bottom-1 -left-1 flex items-center gap-0.5 bg-white px-1.5 py-0.5 rounded-full shadow-sm border border-border">
              <Flame className="w-3 h-3 text-orange-500 fill-orange-500" />
              <span className="text-xs font-semibold">{uploadedPosts.length}</span>
            </div>
          )}
        </div>
        <div>
          <h1 className="text-lg font-semibold text-foreground">httpssu</h1>
          <div className="flex items-center gap-2 text-sm">
            <span><span className="text-cyan-500 font-medium">37</span> <span className="text-muted-foreground">followers</span></span>
            <span><span className="text-cyan-500 font-medium">35</span> <span className="text-muted-foreground">following</span></span>
          </div>
        </div>
      </div>

      {/* Calendar View */}
      {true && (
        <div className="px-4 py-4">
          {/* Month Navigation */}
          <div className="flex items-center justify-center gap-4 mb-4">
            <button className="p-1">
              <ChevronLeft className="w-4 h-4 text-muted-foreground" />
            </button>
            <span className="text-sm font-medium">{currentMonth.month} {currentMonth.year}</span>
            <button className="p-1">
              <ChevronRight className="w-4 h-4 text-muted-foreground" />
            </button>
          </div>

          {/* Week Labels */}
          <div className="grid grid-cols-7 gap-1 mb-2">
            {["S", "M", "T", "W", "T", "F", "S"].map((day, i) => (
              <div key={i} className="text-center text-xs text-muted-foreground py-1">
                {day}
              </div>
            ))}
          </div>

          {/* Calendar Grid */}
          <div className="grid grid-cols-7 gap-1">
            {calendarDays.map((day, i) => (
              <div key={i} className="aspect-square relative">
                {day && (
                  <>
                    <span className="absolute top-0.5 left-1 text-xs text-muted-foreground z-10">
                      {day}
                    </span>
                    {outfitDays[day] && (
                      <div className="absolute inset-0 flex items-center justify-center">
                        <div className="w-8 h-10 bg-gradient-to-b from-muted-foreground/30 to-muted-foreground/50 rounded-sm"></div>
                      </div>
                    )}
                    {day === 20 && uploadedPosts.length > 0 && (
                      <div className="absolute inset-0 flex items-center justify-center overflow-hidden">
                        <img 
                          src={uploadedPosts[0].image} 
                          alt="Uploaded outfit" 
                          className="w-full h-full object-cover rounded-sm"
                        />
                      </div>
                    )}
                  </>
                )}
              </div>
            ))}
          </div>
        </div>
      )}
    </div>
  )

  const renderAdd = () => (
    <div className="flex-1 flex flex-col items-center justify-center px-8 pb-20">
      {/* Hidden File Input */}
      <input
        ref={fileInputRef}
        type="file"
        accept="image/*"
        capture="environment"
        onChange={handleFileChange}
        className="hidden"
      />

      {/* Upload Area */}
      <button 
        onClick={handleCameraClick}
        className="w-full max-w-xs aspect-square border-2 border-dashed border-cyan-400 rounded-2xl flex flex-col items-center justify-center mb-8 bg-cyan-50/30 overflow-hidden"
      >
        {capturedImage ? (
          <img src={capturedImage} alt="Captured outfit" className="w-full h-full object-cover" />
        ) : (
          <div className="flex flex-col items-center text-cyan-500">
            <ImageIcon className="w-12 h-12 mb-2 opacity-60" />
            <span className="text-sm font-medium">slot</span>
            <p className="text-xs text-center mt-2 text-muted-foreground px-4">
              Tap here to upload a picture of your today&apos;s outfit!
            </p>
          </div>
        )}
      </button>

      {/* Camera Button */}
      <button onClick={handleCameraClick} className="mb-12">
        <Camera className="w-8 h-8 text-muted-foreground" />
      </button>

      {/* Send Button */}
      <button 
        onClick={handleSend}
        disabled={!capturedImage}
        className={`text-xl font-semibold tracking-wide transition-colors ${
          capturedImage ? "text-foreground" : "text-muted-foreground"
        }`}
      >
        SEND {">"}
      </button>
    </div>
  )

  const renderSearch = () => {
    const filteredFriends = searchQuery.trim() === "" 
      ? recommendedFriends 
      : recommendedFriends.filter(friend => 
          friend.name.toLowerCase().includes(searchQuery.toLowerCase()) ||
          friend.username.toLowerCase().includes(searchQuery.toLowerCase())
        )

    return (
      <div className="flex-1 overflow-y-auto pb-20">
        {/* Header */}
        <div className="px-4 py-3 flex justify-center">
          <span className="text-cyan-500 font-semibold italic text-lg tracking-wide">WEARLY</span>
        </div>

        {/* Search Bar */}
        <div className="px-4 pb-4">
          <div className="flex items-center gap-2 bg-muted rounded-full px-4 py-2.5">
            <Search className="w-4 h-4 text-muted-foreground" />
            <input 
              type="text" 
              placeholder="Search your friend" 
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
              className="flex-1 bg-transparent text-sm outline-none placeholder:text-muted-foreground"
            />
          </div>
        </div>

        {/* Recommended Friends */}
        <div className="px-4">
          <h2 className="text-sm text-muted-foreground mb-4">Recommended Friends</h2>
          <div className="space-y-4">
            {filteredFriends.map((friend) => (
              <div key={friend.id} className="flex items-center gap-3">
                <div className="w-12 h-12 rounded-full bg-muted"></div>
                <div>
                  <p className="text-cyan-500 font-medium">{friend.name}</p>
                  <p className="text-sm text-muted-foreground">{friend.username}</p>
                </div>
              </div>
            ))}
          </div>
        </div>

        {/* Empty State when no matches */}
        {filteredFriends.length === 0 && (
          <div className="px-4 py-8 text-center text-muted-foreground">
            <p>No friends found matching &quot;{searchQuery}&quot;</p>
          </div>
        )}
      </div>
    )
  }

  const renderNotifications = () => (
    <div className="flex-1 overflow-y-auto pb-20">
      {/* Header */}
      <div className="px-4 py-3 flex items-center">
        <button onClick={() => setShowNotifications(false)} className="mr-4">
          <ChevronLeft className="w-5 h-5 text-foreground" />
        </button>
        <span className="text-cyan-500 font-semibold italic text-lg tracking-wide flex-1 text-center pr-9">Notifications</span>
      </div>

      {/* Friend Requests */}
      <div className="px-4 py-4 border-b border-border">
        <button 
          onClick={() => setShowFriendRequests(true)}
          className="flex items-center justify-between w-full"
        >
          <div className="flex items-center gap-3">
            <Users className="w-5 h-5 text-foreground" />
            <span className="font-medium">Friend requests</span>
          </div>
          <div className="flex items-center gap-1 text-muted-foreground">
            <span>3</span>
            <ChevronRight className="w-4 h-4" />
          </div>
        </button>
      </div>

      {/* Last 7 Days */}
      <div className="px-4 py-4">
        <h2 className="text-xs text-muted-foreground font-medium mb-4">LAST 7 DAYS</h2>
        <div className="space-y-4">
          {notifications.map((notification) => (
            <div key={notification.id} className="flex items-start gap-3">
              <div className="w-10 h-10 rounded-full bg-muted flex-shrink-0"></div>
              <p className="text-sm text-foreground pt-2">{notification.text}</p>
            </div>
          ))}
        </div>
      </div>
    </div>
  )

  const renderFriendRequests = () => (
    <div className="flex-1 overflow-y-auto pb-20">
      {/* Header */}
      <div className="px-4 py-3 flex items-center">
        <button onClick={() => setShowFriendRequests(false)} className="mr-4">
          <ChevronLeft className="w-5 h-5 text-foreground" />
        </button>
        <span className="text-cyan-500 font-semibold italic text-lg tracking-wide flex-1 text-center pr-9">Friend requests</span>
      </div>

      {/* Tabs */}
      <div className="flex border-b border-border mx-4">
        <button 
          onClick={() => setFriendRequestsTab("received")}
          className={`flex-1 py-2 text-sm font-medium border-b-2 transition-colors ${
            friendRequestsTab === "received" 
              ? "text-foreground border-foreground" 
              : "text-muted-foreground border-transparent"
          }`}
        >
          Received (3)
        </button>
        <button 
          onClick={() => setFriendRequestsTab("sent")}
          className={`flex-1 py-2 text-sm font-medium border-b-2 transition-colors ${
            friendRequestsTab === "sent" 
              ? "text-foreground border-foreground" 
              : "text-muted-foreground border-transparent"
          }`}
        >
          Sent
        </button>
      </div>

      {/* Content */}
      {friendRequestsTab === "received" ? (
        <div className="px-4 py-4">
          <div className="space-y-4">
            {friendRequests.map((request) => (
              <div key={request.id} className="flex items-center gap-3">
                <div className="w-12 h-12 rounded-full bg-muted"></div>
                <div>
                  <p className="text-cyan-500 font-medium">{request.name}</p>
                  <p className="text-sm text-muted-foreground">{request.username}</p>
                </div>
              </div>
            ))}
          </div>
        </div>
      ) : (
        <div className="flex flex-col items-center justify-center py-20 px-8 text-center">
          <p className="text-cyan-500 font-medium mb-2">It&apos;s empty here!</p>
          <p className="text-sm text-muted-foreground">
            Try sending friend requests from your recommended friends list.
          </p>
        </div>
      )}
    </div>
  )

  const renderSettings = () => (
    <div className="flex-1 overflow-y-auto pb-20 bg-background">
      {/* Header */}
      <div className="px-4 py-3 flex items-center">
        <button onClick={() => setShowSettings(false)}>
          <ChevronLeft className="w-5 h-5 text-foreground" />
        </button>
        <span className="text-red-400 font-medium italic text-lg flex-1 text-center">Settings</span>
        <div className="w-5" />
      </div>

      {/* User Profile Card */}
      <div className="px-4 py-3">
        <div className="flex items-center justify-between bg-muted/30 rounded-2xl px-4 py-3 border border-border/50">
          <div className="flex items-center gap-3">
            <div className="w-11 h-11 rounded-full bg-muted border border-border/50 overflow-hidden">
              <img src="https://hebbkx1anhila5yf.public.blob.vercel-storage.com/image-se3x2GwtYowXEv9BuXujrP5F9U6bMq.png" alt="Profile" className="w-full h-full object-cover" />
            </div>
            <div>
              <p className="font-semibold text-foreground text-sm">Kelly</p>
              <p className="text-xs text-muted-foreground">suue.o4</p>
            </div>
          </div>
          <ChevronRight className="w-5 h-5 text-muted-foreground" />
        </div>
      </div>

      {/* Settings Section */}
      <div className="px-4 pt-4">
        <p className="text-xs text-muted-foreground mb-1 px-1">Settings</p>
        <div>
          <button 
            onClick={handleNotificationsFromSettings}
            className="flex items-center justify-between w-full py-3.5 px-1"
          >
            <div className="flex items-center gap-3">
              <Bell className="w-5 h-5 text-foreground" />
              <span className="text-foreground text-sm">Notifications</span>
            </div>
            <ChevronRight className="w-5 h-5 text-muted-foreground" />
          </button>
          <button className="flex items-center justify-between w-full py-3.5 px-1">
            <div className="flex items-center gap-3">
              <Lock className="w-5 h-5 text-foreground" />
              <span className="text-foreground text-sm">Privacy</span>
            </div>
            <ChevronRight className="w-5 h-5 text-muted-foreground" />
          </button>
        </div>
      </div>

      {/* About Section */}
      <div className="px-4 pt-4">
        <p className="text-xs text-muted-foreground mb-1 px-1">About</p>
        <div>
          <button 
            onClick={() => setShowHelp(true)}
            className="flex items-center justify-between w-full py-3.5 px-1"
          >
            <div className="flex items-center gap-3">
              <HelpCircle className="w-5 h-5 text-foreground" />
              <span className="text-foreground text-sm">Help</span>
            </div>
            <ChevronRight className="w-5 h-5 text-muted-foreground" />
          </button>
          <button className="flex items-center justify-between w-full py-3.5 px-1">
            <div className="flex items-center gap-3">
              <Info className="w-5 h-5 text-foreground" />
              <span className="text-foreground text-sm">About</span>
            </div>
            <ChevronRight className="w-5 h-5 text-muted-foreground" />
          </button>
        </div>
      </div>

      {/* Action Buttons */}
      <div className="px-4 pt-8 space-y-3">
        <button className="w-full py-3 rounded-full border border-red-400 text-red-400 font-medium text-sm">
          Log Out
        </button>
        <button className="w-full py-3 rounded-full border border-cyan-400 text-cyan-400 font-medium text-sm">
          Delete Account
        </button>
      </div>
    </div>
  )

  const renderNotificationSettings = () => (
    <div className="flex-1 overflow-y-auto pb-20 bg-background">
      {/* Header */}
      <div className="px-4 py-3 flex items-center border-b border-border">
        <button onClick={() => setShowNotificationSettings(false)}>
          <ChevronLeft className="w-5 h-5 text-foreground" />
        </button>
        <span className="text-cyan-500 font-semibold italic text-lg flex-1 text-center pr-5">Notifications</span>
      </div>

      {/* Notification Toggle Options */}
      <div className="px-6 pt-8 space-y-6">
        {/* Friend requests */}
        <div className="flex items-center justify-between">
          <span className="text-foreground text-sm">Friend requests</span>
          <button
            onClick={() => toggleNotificationSetting('friendRequests')}
            className={`relative w-12 h-7 rounded-full transition-colors duration-200 ${
              notificationToggles.friendRequests ? 'bg-green-500' : 'bg-muted-foreground/30'
            }`}
          >
            <div
              className={`absolute top-0.5 w-6 h-6 rounded-full bg-white shadow-md transition-transform duration-200 ${
                notificationToggles.friendRequests ? 'translate-x-5' : 'translate-x-0.5'
              }`}
            />
          </button>
        </div>

        {/* Comments */}
        <div className="flex items-center justify-between">
          <span className="text-foreground text-sm">Comments</span>
          <button
            onClick={() => toggleNotificationSetting('comments')}
            className={`relative w-12 h-7 rounded-full transition-colors duration-200 ${
              notificationToggles.comments ? 'bg-green-500' : 'bg-muted-foreground/30'
            }`}
          >
            <div
              className={`absolute top-0.5 w-6 h-6 rounded-full bg-white shadow-md transition-transform duration-200 ${
                notificationToggles.comments ? 'translate-x-5' : 'translate-x-0.5'
              }`}
            />
          </button>
        </div>

        {/* Likes */}
        <div className="flex items-center justify-between">
          <span className="text-foreground text-sm">Likes</span>
          <button
            onClick={() => toggleNotificationSetting('likes')}
            className={`relative w-12 h-7 rounded-full transition-colors duration-200 ${
              notificationToggles.likes ? 'bg-green-500' : 'bg-muted-foreground/30'
            }`}
          >
            <div
              className={`absolute top-0.5 w-6 h-6 rounded-full bg-white shadow-md transition-transform duration-200 ${
                notificationToggles.likes ? 'translate-x-5' : 'translate-x-0.5'
              }`}
            />
          </button>
        </div>
      </div>
    </div>
  )

  const renderHelp = () => (
    <div className="flex-1 overflow-y-auto pb-20 bg-background">
      {/* Header */}
      <div className="px-4 py-3 flex items-center border-b border-border">
        <button onClick={() => setShowHelp(false)}>
          <ChevronLeft className="w-5 h-5 text-foreground" />
        </button>
        <span className="text-cyan-500 font-semibold italic text-lg flex-1 text-center pr-5">Help</span>
      </div>

      {/* Help Content */}
      <div className="px-6 pt-8 space-y-2">
        <p className="text-foreground text-sm">Contact: helpwearly.com</p>
        <p className="text-foreground text-sm">Phone Number: (000)-000-0000</p>
      </div>
    </div>
  )

  const renderComments = () => {
    const isUploadedPost = selectedUploadedPost !== null
    const post = isUploadedPost ? selectedUploadedPost : selectedPost
    
    if (!post) return null
    
    const comments = isUploadedPost 
      ? (uploadedPostComments[post.id] || [])
      : (postComments[post.id] || [])

    return (
      <div className="flex-1 flex flex-col pb-20">
        <div className="flex-1 overflow-y-auto">
          {/* Back button */}
          <div className="px-4 py-2">
            <button onClick={() => {
              setShowComments(false)
              setSelectedPost(null)
              setSelectedUploadedPost(null)
            }}>
              <ChevronLeft className="w-5 h-5 text-foreground" />
            </button>
          </div>

          {/* User Info Header */}
          <div className="px-4 py-3 flex items-center gap-3">
            <div className="w-10 h-10 rounded-full bg-muted overflow-hidden">
              {isUploadedPost ? (
                <img src="https://hebbkx1anhila5yf.public.blob.vercel-storage.com/image-se3x2GwtYowXEv9BuXujrP5F9U6bMq.png" alt="Profile" className="w-full h-full object-cover" />
              ) : (
                <div className="w-full h-full bg-gradient-to-br from-muted to-muted-foreground/20"></div>
              )}
            </div>
            <div>
              <p className="font-medium text-foreground text-sm">
                {isUploadedPost ? "httpssu" : (selectedPost?.username || "")}
              </p>
              <p className="text-xs text-muted-foreground">
                {isUploadedPost ? "Just now" : (selectedPost?.timeAgo || "")}
              </p>
            </div>
          </div>

          {/* Post Card */}
          <div className="px-4">
            <div className="relative bg-card rounded-2xl overflow-hidden shadow-sm border border-border">
              {/* Tag */}
              {post.tag && (
                <div className="absolute top-3 left-3 flex items-center gap-1.5 text-cyan-500 z-10">
                  {getTagIcon(post.tag.icon)}
                  <span className="text-sm font-medium">{post.tag.label}</span>
                </div>
              )}

              {/* Image */}
              <div className="aspect-square bg-gradient-to-br from-muted/50 to-muted flex items-center justify-center overflow-hidden">
                {isUploadedPost && selectedUploadedPost ? (
                  <img src={selectedUploadedPost.image} alt="Uploaded outfit" className="w-full h-full object-contain" />
                ) : (
                  <div className="w-48 h-64 bg-gradient-to-b from-muted-foreground/20 to-muted-foreground/40 rounded-lg"></div>
                )}
              </div>
            </div>
          </div>

          {/* Comments Section */}
          <div className="px-4 py-4">
            <h2 className="text-base font-medium mb-4">Comments {post.comments}</h2>
            <div className="space-y-4">
              {comments.length === 0 ? (
                <p className="text-sm text-muted-foreground">No comments yet. Be the first to comment!</p>
              ) : (
                comments.map((comment) => (
                  <div key={comment.id} className="flex items-start gap-3">
                    <div className="w-10 h-10 rounded-full bg-muted flex-shrink-0 overflow-hidden">
                      {comment.username === "suue.04" ? (
                        <img src="https://hebbkx1anhila5yf.public.blob.vercel-storage.com/image-se3x2GwtYowXEv9BuXujrP5F9U6bMq.png" alt="Profile" className="w-full h-full object-cover" />
                      ) : (
                        <div className="w-full h-full bg-gradient-to-br from-muted to-muted-foreground/20"></div>
                      )}
                    </div>
                    <div>
                      <div className="flex items-center gap-2">
                        <span className="font-semibold text-sm">{comment.username}</span>
                        <span className="text-xs text-muted-foreground">{comment.timeAgo}</span>
                      </div>
                      <p className="text-sm text-foreground">{comment.text}</p>
                      <button className="text-xs text-muted-foreground mt-1">Reply</button>
                    </div>
                  </div>
                ))
              )}
            </div>
          </div>
        </div>

        {/* Comment Input */}
        <div className="px-4 py-3 border-t border-border bg-background">
          <input
            type="text"
            placeholder="Start the conversation..."
            value={commentInput}
            onChange={(e) => setCommentInput(e.target.value)}
            onKeyDown={(e) => e.key === "Enter" && handleAddComment()}
            className="w-full bg-muted rounded-full px-4 py-3 text-sm outline-none placeholder:text-muted-foreground"
          />
        </div>
      </div>
    )
  }

  return (
    <div className="min-h-screen bg-background flex flex-col max-w-md mx-auto">
      {/* Content */}
      {showComments ? (
        renderComments()
      ) : showHelp ? (
        renderHelp()
      ) : showNotificationSettings ? (
        renderNotificationSettings()
      ) : showSettings ? (
        renderSettings()
      ) : showFriendRequests ? (
        renderFriendRequests()
      ) : showNotifications ? (
        renderNotifications()
      ) : (
        <>
          {activeTab === "feed" && renderFeed()}
          {activeTab === "calendar" && renderProfile()}
          {activeTab === "add" && renderAdd()}
          {activeTab === "search" && renderSearch()}
        </>
      )}

      {/* Bottom Navigation - hide when viewing comments */}
      {!showComments && (
        <div className="fixed bottom-0 left-0 right-0 max-w-md mx-auto bg-background border-t border-border">
          <div className="flex items-center justify-around py-3 px-6">
            <button
              onClick={() => setActiveTab("feed")}
              className={`flex flex-col items-center gap-1 ${activeTab === "feed" ? "text-pink-500" : "text-muted-foreground"}`}
            >
              <Home className="w-6 h-6" />
              <span className="text-xs">Feed</span>
            </button>
            <button
              onClick={() => setActiveTab("calendar")}
              className={`flex flex-col items-center gap-1 ${activeTab === "calendar" ? "text-cyan-500" : "text-muted-foreground"}`}
            >
              <Calendar className="w-6 h-6" />
              <span className="text-xs">Calendar</span>
            </button>
            <button
              onClick={() => setActiveTab("add")}
              className={`flex flex-col items-center gap-1 ${activeTab === "add" ? "text-cyan-500" : "text-muted-foreground"}`}
            >
              <PlusSquare className="w-6 h-6" />
              <span className="text-xs">Add</span>
            </button>
            <button
              onClick={() => setActiveTab("search")}
              className={`flex flex-col items-center gap-1 ${activeTab === "search" ? "text-cyan-500" : "text-muted-foreground"}`}
            >
              <Search className="w-6 h-6" />
              <span className="text-xs">Search</span>
            </button>
          </div>
          {/* Home Indicator */}
          <div className="flex justify-center pb-2">
            <div className="w-32 h-1 bg-foreground rounded-full"></div>
          </div>
        </div>
      )}
    </div>
  )
}
